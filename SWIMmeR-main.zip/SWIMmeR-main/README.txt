Copyright 2020 Paola Paci

SWIMmeR is a free software. See the file LICENSE for copying conditions.

Author: Paola Paci (paci@diag.uniroma1.it)

See the User Guide for instructions on how to use SWIMmeR.
